import react from 'react'
import './MyStyle.css'
function StyleSheets(){
    return(
        <h1 className="Hello">Welcome to StyleSheets</h1>
    )
}
export default StyleSheets