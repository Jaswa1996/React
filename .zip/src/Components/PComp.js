import react,{PureComponent} from 'react'
class PComp extends PureComponent{
    render(){
        console.log("PureComp render")
        return(
            <div>
                PureComponent{this.props.name}
            </div>
        )
    }
}
export default PComp