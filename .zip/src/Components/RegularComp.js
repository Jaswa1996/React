import react,{Component} from 'react'
class RegularComp extends Component{
    render(){
        console.log("RegComponent Render")
        return(
            <div>
                RegularComponent{this.props.name}
            </div>
        )
    }
}
export default RegularComp