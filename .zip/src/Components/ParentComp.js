import react,{Component} from 'react'
import RegularComp from './RegularComp'
import PComp from './PComp'
import MemoDemo from './MemoDemo'
class ParentComp extends Component{
    constructor(){
        super()
        this.state={
            name:'Jaswanth'
        }
    }
    componentDidMount(){
        setInterval(() =>{
            this.setState({
                name:'Jaswanth'
            })
        },2000)
    }
   render(){
       console.log("************ParentComponentRender ***********")
        return(
            <div>
                <h1>ParentComponent</h1>
                <MemoDemo name ={this.state.name}/>
                {/* <PComp name={this.state.name}></PComp>
                <RegularComp name={this.state.name}></RegularComp> */}
            </div>
        )
    }
}
export default ParentComp