    import React,{useState} from 'react'
    function TodoList (){
        const[itemList,setItemList] = useState("Buy A Apple")
        const[itemsList,setItemsList] = useState([])
        const eventItems = (e) =>{
            setItemList(e.target.value)
        }
        const listItem = () =>{
         setItemsList((prevItem) =>{
             return[...prevItem,itemList]
         })
        }
        return(
            <>
            <div className="main-content">
                <div className="center-align">
                    <h1>TodoList</h1>
                    <input type="text" placeholder="Add A item " value ={itemList}onChange={eventItems}/>
                    <button onClick={listItem}>+</button>
                 <ol>
                    {/* <li>{itemList}</li> */}
                   {
                   itemsList.map((itemVal) =>{
                      return <li>{itemVal}</li>
                   })}
                 </ol>

                </div>
            </div>
            </>
        )
    }
export default TodoList    