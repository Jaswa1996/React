import React,{Component} from 'react'
class LifeCycleB extends Component{
    constructor(){
        super()
        this.state={
            name:'Viswas'
        }
        console.log("LifeCYcleB Constructor")
    }
    static getDerivedStateFromProps(props,state){
        console.log("LifeCycleB getDerivedStateFromProps")
        return null
    }
    componentDidMount(){
        console.log("LifeCycleB ComponentDidMount ")
    }
    render(){
        console.log("LifeCYcleB Render")
        return(
            <h1>LifeCYcleB</h1>
        )
    }
}
export default LifeCycleB