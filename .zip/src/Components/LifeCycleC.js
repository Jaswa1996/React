import React,{Component} from 'react'
class LifeCycleC extends Component{
    constructor(){
        super()
        this.state={
            name:'Jagan'
        }
    }
    static getDerivedStateFromProps(props,state){
        console.log("LifeCycleC getDerivedStateFromProps")
        return null
    }
    shouldComponentUpdate(){
        console.log("LifeCycleC shouldComponentUpdate")
        return true 
    }
     getSnapshotBeforeUpdate(prevProps,prevState){
        console.log("LifeCycleC getsnapShotBeforeUpdate")
        return null
    }
    componentDidUpdate(prevprops,prevstate,snapshot){
        console.log("LifeCycleC ComponentUpdate")
    }
    render(){
        console.log("LifeCycleC Render")
        return(
             <div>
                 <h1>LifeCycleC</h1>
             </div>
        )
    }
}
export default LifeCycleC