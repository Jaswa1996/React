import react,{Component} from 'react'
class ConditionalRendering extends Component {
    constructor(){
        super()
        this.state={
            isLoggedIn: false
        }
    }
    render() {
      return   this.state.isLoggedIn && <div>Welcome Dhoni</div>
        // return(
        //     // this.state.isLoggedIn?(
        //     // <div>Welcome Jashu</div> ):(
        //     // <div>Welcome Guest</div>)
        // )
        // let Message
        // if (this.state.isLoggedIn){
        //     Message=<div>Welcome Viswas</div>

        // }
        // else{
        //     Message=<div>Welcome Guest</div>
        // }
        // return <div>{Message}</div>
        // if(this.state.isLoggedIn){
        //     return(
        //         <div>
        //             welcome Viswas
        //         </div>
        //     )
        // }
        // else{
        //     return(
        //         <div>
        //             welcome Guest
        //         </div>
        //     )
        // }
        // return (
        //     <div>
        //         <h1>welcome viswas</h1>
        //         <div>Welcome Guest</div>
        //     </div>
        // );
    }
}
export default ConditionalRendering
