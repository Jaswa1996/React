import React,{Component} from 'react'
import ChildComponent from './ChildComponent'
class ParentComponent extends Component{
    constructor(){
        super()
        this.state={
            message:'parent'
        }
        this.greetParent=this.greetParent.bind(this)
    }
    greetParent(childName,firstName){
        alert(`hello ${this.state.message} from ${childName} and ${firstName}`)
    }
    render(){
        return(
            <ChildComponent greetHandler={this.greetParent}/>
        )
    }
}
export default ParentComponent