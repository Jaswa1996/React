import React,{Component} from 'react'
class EventBind extends Component{
    render(){
        return(
            <div>
                <button>Clcik</button>
            </div>
        )
    }
}