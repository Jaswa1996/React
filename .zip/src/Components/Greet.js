import React from 'react'
// function Function(){
//     return(
//         <div>
//             <h1>Welcome to functional Components</h1>
//         </div>
//     )
// }
const Greet =(props) =>{
    const{sources,destination} =props
    
    return(
        <div>
        <h1>Hello Orange</h1>
        <h1> Redbus {sources} Abhibus {destination}</h1>
        
        </div>
    )
}
export default Greet