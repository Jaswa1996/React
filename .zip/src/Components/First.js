import React, {useState} from 'react';

const First = () =>{

const[newData, setNewData] = useState(true)

const hideData=()=>{
       setNewData(false)
    }

    return(
    <>
    {
        newData ? <div><h1>hi</h1></div> : null
    }
        
        <button onClick={hideData}>Hide</button>
    </>
    )
}

export default First