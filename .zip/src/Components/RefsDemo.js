import React,{Component} from 'react'
class RefsDemo extends Component{
    constructor(){
        super()
        this.inpRef=React.createRef()
    }
    componentDidMount(){
        this.inpRef.current.focus()
        console.log("This .inpRef")
    }
    clickHandler = () =>{
        alert(this.inpRef.current.value)
    }
    render(){
        return(
             <div>
              <input type="text" ref={this.inpRef}/>
              <button onClick={() =>this.clickHandler()}>Click</button>
             </div>
        )
    }
}
export default RefsDemo