import React,{Component} from 'react'
class   Welcome extends Component {

    render(){
        const{name,lastName} =this.props
        return(
            <div>
            <h1>Hello {name} aka {lastName}</h1>
            
            </div>
        )
    }
}
export default Welcome