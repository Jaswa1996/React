import React,{Component} from 'react'
import LifeCYcleB from './LifeCycleB'
class LifeCycleA extends Component{
    constructor(){
        super()
        this.state={
            name:"Jagan"
        }
        console.log("LifeCycleA Constructor")
    }
    static getDerivedStateFromProps(props,state){
        console.log("LifeCycleA getDerivedStateFromProps")
        return null
    }
    componentDidMount(){
        console.log("LifeCycleA ComponentDidMount")
    }
    render(){
        console.log("LifeCycleA render")
        return(
            <div>
            <h1>LifeCycleA</h1>
            <LifeCYcleB/>            
            </div>
        )
    }
} 
export default LifeCycleA
