import React from 'react'
const heading ={
    fontsize :'25px',
    color :"Blue",
    

}
function Inline(){
    return(
        <h1 style={heading}>Inline</h1>
    )
}
export default Inline