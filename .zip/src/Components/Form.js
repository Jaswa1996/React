
import React,{Component} from 'react'
class Form extends Component{
    constructor(){
        super()
        this.state={
            userName:"",
            content:"",
            courses:""
        }
    }
    render(){
        return(
            <Form>
                <div>
                    <label>userName:</label>
                    <input type="text" value={this.state.userName}/>
                </div>
            </Form>

            
        )
    }
    }
export default Form