import React from 'react'
import Columnn from './Column'
import Column from './Column'
function Table(){
    return(
        <table>
            <th>
                <tr>
                  <Columnn/>
                </tr>
            </th>
        </table>

        
    )
}
export default Table