import React from 'react'
import Person from './Person'


function NameList(){
    // const names=['Bruce','Diana','Jashu']
    // const namesList=names.map(name =><h2>{name}</h2>)
    // return(
    //    <div>{namesList}</div>
    // )
    const persons =[
        {
            id:1,
            name:'Jashu',
            age:20
        },

        {
            id:2,
            name:'Chinni',
            age:30
        },
        { 
            id:3,
            name:'Dhoni',
            age:45
        }
    ]
    const personList =persons.map(person => <Person  key={person.id} person ={person}/> )
    
    return(
        <div>{personList}</div>
        
    )

}

export default NameList