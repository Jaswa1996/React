import React,{Component} from 'react'
import  './Hello.css'
class Forms1 extends Component{
    constructor(props){
        super(props)
        this.state={
            name:"",
            comments:"",
            Routes:""
        }
    }
    changeHandle =(e) =>{
        this.setState({
            name:e.target.value,
            
        })
    }
    changeComments = (e) =>{
        this.setState({
            comments:e.target.value
         } )
    }
    changeRoutes = (e) =>{
        this.setState({
            Routes:e.target.value
        })
    }
    handleSubmit = (event) =>{
        alert(`Hello my name is${this.state.name} my content is ${this.state.comments} my routes are ${this.state.Routes}`)
        event.preventDefault()
    }
    render(){
        return(
            <div className="Hello">
                 <form onSubmit={this.handleSubmit}>
                <div>
                    <label>Name:</label>
                    <input type="text" value={this.state.name} onChange={this.changeHandle}/>
                </div>
                <div>
                    <label>Comments</label>
                    <input type="text"value={this.state.comments} onChange={this.changeComments}/>
                </div>
                <div>
                    <label>Routes</label>
                    <select value={this.state.Routes} onChange={this.changeRoutes}>
                        <option value="Hyderabad">Hyderabad</option>
                        <option value="Bengaluru">Bengaluru</option>
                        <option value="Visakhapatnam">Visakhapatnam</option>
                    </select>
                </div>
                <button type="submit">Submit</button>

            </form>
            </div>
           
        )
    }
}
export default Forms1

