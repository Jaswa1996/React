import React,{Component} from 'react'
class ClassClick extends Component{
     clickHandler(){
         console.log("Thank you")
     }
    render(){
        return(
            <div>
            <h1>Class Click</h1>
            <button onClick={this.clickHandler}>ClickMe</button>
            </div>
            
        )
    }
}
export default ClassClick