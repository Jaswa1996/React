import React from 'react'
function FragmentDemo(){
    return(
        <React.Fragment>
        <h1>
            Fragment Demo
        </h1>
        <p>This is Describes Fragment Demo</p>
        </React.Fragment>
    )
}
export default FragmentDemo
